@echo off
REM =============================================================
REM  Compila perfil_launcher.py como AsistentePerfiles.exe
REM  Ejecutar este archivo DENTRO de Windows, en la misma carpeta
REM  donde esta perfil_launcher.py (doble clic o desde consola).
REM =============================================================

setlocal

where python >nul 2>nul
if errorlevel 1 (
    echo No se encontro Python en el PATH. Instalalo desde https://python.org
    echo y vuelve a intentarlo.
    pause
    exit /b 1
)

echo Instalando herramientas de compilacion y dependencias...
python -m pip install --upgrade pip --quiet
python -m pip install --quiet pyinstaller pillow pystray pywin32

echo.
echo Compilando AsistentePerfiles.exe (esto puede tardar 1-2 minutos)...
python -m PyInstaller --onefile --windowed --name "AsistentePerfiles" perfil_launcher.py

echo.
if exist "dist\AsistentePerfiles.exe" (
    echo Listo. Encontraras el ejecutable en:
    echo   dist\AsistentePerfiles.exe
    echo.
    echo Puedes moverlo a donde quieras y anclarlo tu mismo a la barra de
    echo tareas o al escritorio ^(clic derecho sobre el .exe -^> Anclar a la
    echo barra de tareas^). La app seguira guardando tus perfiles en
    echo %%APPDATA%%\PerfilLauncher\perfiles.json sin importar desde donde la abras.
) else (
    echo Algo fallo durante la compilacion. Revisa los mensajes de arriba.
)
pause
